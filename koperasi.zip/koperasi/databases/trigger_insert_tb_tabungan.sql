DELIMITER $$

USE `koperasi`$$

DROP TRIGGER /*!50032 IF EXISTS */ `insert_tb_tabungan`$$

CREATE
    /*!50017 DEFINER = 'root'@'localhost' */
    TRIGGER `insert_tb_tabungan` AFTER INSERT ON `tb_anggota` 
    FOR EACH ROW BEGIN
	INSERT INTO tb_tabungan SET jumlah = NEW.saldo, id_anggota= NEW.id_anggota, kode_user= NEW.kode_user;
    END;
$$

DELIMITER ;