SELECT * FROM tb_anggota;
SELECT * FROM tb_simpanan;
SELECT * FROM tb_pinjaman;

SELECT CONCAT('Rp. ', FORMAT(simpanan_pokok + simpanan_wajib + simpanan_sukarela,0)) AS tabungan FROM tb_anggota WHERE id_anggota='AGT0001';

SELECT SUM(jumlah) AS jumlah FROM tb_simpanan;

SELECT id_anggota, tgl_join, CURRENT_DATE() AS tgl_sekarang,
TIMESTAMPDIFF(YEAR, tgl_join, CURRENT_DATE()) AS selisilh_join,
TIMESTAMPDIFF(YEAR, '1992-11-03', CURRENT_DATE()) AS Tahun,
TIMESTAMPDIFF(MONTH, '1992-11-03', CURRENT_DATE()) AS Bulan,
TIMESTAMPDIFF(DAY, '1992-11-03', CURRENT_DATE()) AS hari
FROM tb_anggota;

SELECT id_anggota, tgl_join, CURRENT_DATE() AS tgl_sekarang,
TIMESTAMPDIFF(YEAR, tgl_join, CURRENT_DATE()) AS selisilh_join,
TIMESTAMPDIFF(YEAR, tgl_join, CURRENT_DATE()) AS Tahun,
TIMESTAMPDIFF(MONTH, tgl_join, CURRENT_DATE()) AS Bulan,
TIMESTAMPDIFF(DAY, tgl_join, CURRENT_DATE()) AS hari
FROM tb_anggota;

SELECT * FROM tb_simpanan;
SELECT simpanan_pokok + simpanan_wajib + simpanan_sukarela AS saldo FROM tb_anggota;

SELECT simpanan_pokok, @tot := simpanan_pokok + simpanan_wajib + simpanan_sukarela AS total, @h:=(@tot + SUM(jumlah)) AS hasil,
ROUND(@tot - simpanan_pokok) AS kurang
FROM tb_anggota X
INNER JOIN tb_simpanan Y ON Y.id_anggota = X.id_anggota
WHERE X.id_anggota ='AGT0001'; 

SELECT  simpanan_pokok + simpanan_wajib + simpanan_sukarela AS saaldo, saldo + jumlah
FROM tb_anggota X
INNER JOIN tb_simpanan Y ON Y.id_anggota = X.id_anggota;

SELECT * FROM tb_persetujuan;
SELECT id_pinjam, tgl_pinjam, CONCAT('Rp. ', FORMAT(jumlah,0)) AS jumlah, CONCAT(bunga,'%')AS bunga,
lama_cicilan, CONCAT('Rp. ', FORMAT(angsuran,0)) AS angsuran, CONCAT('Rp. ', FORMAT(hutang,0)) AS hutang, kode_user, id_anggota
FROM tb_persetujuan;

SELECT * FROM tb_pinjaman;
DELETE tb_pinjaman SET id_pinjaman WHERE id_pinjaman='PIN0'
SELECT * FROM tb_persetujuan;

DELETE FROM tb_persetujuan WHERE id_pinjam='PIN0001';

SELECT * FROM tb_pinjaman;
SELECT CONCAT('Rp. ', FORMAT(SUM(hutang),0)) AS hutang FROM tb_pinjaman;

SELECT * FROM tb_angsuran;
SELECT CONCAT('Rp. ', FORMAT(SUM(sisa_pinjaman),0)) AS sisa_pinjaman FROM tb_angsuran;
SELECT * FROM tb_pinjaman;
SELECT IF (hutang <= 0, 'True', 'False') FROM tb_pinjaman WHERE id_anggota='AGT0002';

UPDATE tb_pinjaman SET lama_cicilan='6', hutang='3150000' WHERE id_anggota = 'AGT0001';

DELETE FROM tb_pinjaman WHERE id_anggota ='AGT0001';
SELECT * FROM jenis_simpanan;
UPDATE jenis_simpanan SET pokok='150000' WHERE id_jenis='JNS01';
SELECT * FROM tb_pinjaman WHERE id_anggota LIKE '%0002%';

SELECT * FROM tb_anggota;
SELECT * FROM tb_simpanan;
SELECT * FROM tb_pinjaman;
SELECT * FROM tb_angsuran;
SELECT id_simpanan, tgl_simpan, jenis_simpanan, jumlah, X.kode_user, X.id_anggota, nama_lengkap
FROM tb_simpanan X
INNER JOIN tb_anggota Y ON Y.`id_anggota` = X.`id_anggota` WHERE Y.id_anggota='AGT0001';

SELECT id_pinjam, tgl_pinjam, CONCAT('Rp. ', FORMAT(jumlah,0)) AS jumlah, CONCAT(bunga,'%')AS bunga,
lama_cicilan, CONCAT('Rp. ',`delete_persetujuan` FORMAT(angsuran,0)) AS angsuran, CONCAT('Rp. ', FORMAT(hutang,0)) AS hutang,
X.kode_user, X.id_anggota, nama_lengkap
FROM tb_persetujuan X
INNER JOIN tb_anggota Y ON Y.`id_anggota` = X.`id_anggota`;

SELECT id_pinjaman, tgl_pinjam, jumlah, bunga, lama_cicilan, angsuran, hutang, X.kode_user, X.id_anggota, nama_lengkap
FROM tb_pinjaman X 
INNER JOIN tb_anggota Y ON Y.id_anggota = X.id_anggota;
DELETE FROM tb_pinjaman WHERE hutang ='0';
SHOW TRIGGERS

SELECT * FROM tb_anggota WHERE id_anggota LIKE '%AGT000%' AND nama_lengkap LIKE '%a%';

SELECT id_simpanan, tgl_simpan, jenis_simpanan, jumlah, X.kode_user, X.id_anggota, 
nama_lengkap FROM tb_simpanan X INNER JOIN tb_anggota Y ON Y.id_anggota = X.id_anggota 
WHERE id_simpanan LIKE '%SMPN000%' OR X.id_anggota LIKE '%AGT000%' OR nama_lengkap LIKE '%Andi%';
SELECT * FROM tb_angsuran;
SELECT no_pengembalian, tgl_bayar, jumlah, sisa_pinjaman, cicilan, keterangan, X.kode_user, X.id_pinjaman, X.id_anggota, nama_lengkap
FROM tb_angsuran X
INNER JOIN tb_anggota Y ON Y.`id_anggota` = X.`id_anggota`;
SELECT * FROM tb_persetujuan;
SELECT id_pinjam, tgl_pinjam, jumlah, bunga, lama_cicilan, angsuran, hutang, X.kode_user, X.id_anggota, nama_lengkap
FROM tb_persetujuan X
INNER JOIN tb_anggota Y ON Y.`id_anggota` = X.`id_anggota`;

SELECT id_pinjam, tgl_pinjam, CONCAT('Rp. ', FORMAT(jumlah,0)) AS jumlah, CONCAT(bunga,'%')AS bunga, 
lama_cicilan, CONCAT('Rp. ', FORMAT(angsuran,0)) AS angsuran, CONCAT('Rp. ', FORMAT(hutang,0)) AS hutang, 
X.kode_user, X.id_anggota, nama_lengkap FROM tb_persetujuan X INNER JOIN tb_anggota Y ON Y.id_anggota = X.id_anggota

SELECT CONCAT('Rp. ', FORMAT(SUM(simpanan_pokok + simpanan_wajib + simpanan_sukarela),0)) AS tabungan FROM tb_anggota

SELECT * FROM tb_anggota;
SELECT * FROM tb_simpanan;
SELECT * FROM tb_pinjaman;
SELECT * FROM tb_angsuran;

SELECT X.kode_user AS KU, X.id_anggota AS IA, tgl_join TJA, simpanan_pokok AS SPA, 
simpanan_wajib AS SWA, simpanan_sukarela AS SSA, saldo AS SA, id_simpanan AS ISI, Y.jumlah AS JS,
Z.id_pinjaman AS IP, tgl_pinjam AS TP, Z.jumlah AS JP, bunga AS BU, lama_cicilan AS LC, angsuran AS ANGSR, hutang AS HU
FROM tb_anggota X INNER JOIN tb_simpanan Y ON Y.`id_anggota` = X.`id_anggota`
INNER JOIN tb_pinjaman Z ON Z.`id_anggota` = X.`id_anggota` ;

SELECT kode_user AS KU, id_anggota AS IA, tgl_join TJA, simpanan_pokok AS SPA, 
simpanan_wajib AS SWA, simpanan_sukarela AS SSA, saldo AS SA FROM tb_anggota;

SELECT id_simpanan AS ISI, tgl_simpan AS TS, jumlah AS JS FROM tb_simpanan;

SELECT id_pinjaman AS IP, tgl_pinjam AS TP, jumlah AS JP, bunga AS BU, lama_cicilan AS LC, angsuran AS ANGSR, hutang AS HU FROM tb_pinjaman;

SELECT * FROM tb_pinjaman;

SELECT id_pinjaman, tgl_pinjam, jumlah, bunga, lama_cicilan, angsuran, hutang, X.kode_user, X.id_anggota, nama_lengkap
FROM tb_pinjaman X
INNER JOIN tb_anggota Y ON Y.id_anggota = X.id_anggota;

SELECT * FROM tb_simpanan;

SELECT id_simpanan, tgl_simpan, jenis_simpanan, jumlah, X.kode_user, X.id_anggota, nama_lengkap
FROM tb_simpanan X INNER JOIN tb_anggota Y ON Y.`id_anggota` = X.`id_anggota` 
WHERE X.id_anggota=X.id_anggota;

SELECT * FROM tb_pinjaman;
SELECT * FROM tb_angsuran;
SELECT  X.id_pinjaman, tgl_pinjam, X.jumlah, bunga, lama_cicilan + cicilan AS lama_cicilan, angsuran , angsuran *(lama_cicilan+cicilan) AS hutang, X.kode_user, X.id_anggota, nama_lengkap
FROM tb_pinjaman X
INNER JOIN tb_angsuran Y ON Y.id_anggota = X.id_anggota
INNER JOIN tb_anggota Z ON Z.id_anggota = X.id_anggota;

SELECT X.id_pinjaman, tgl_pinjam, X.jumlah, bunga, lama_cicilan+cicilan AS lama_cicilan, angsuran, hutang, X.kode_user, X.id_anggota
FROM tb_pinjaman X
INNER JOIN tb_angsuran Y ON Y.`id_anggota` = X.`id_anggota`;

SELECT DISTINCT no_pengembalian, tgl_bayar, X.jumlah AS jumlah, sisa_pinjaman, cicilan, keterangan, X.kode_user, X.id_pinjaman, X.id_anggota, nama_lengkap
FROM tb_angsuran X
INNER JOIN tb_pinjaman Y ON Y.id_anggota = X.id_anggota
INNER JOIN tb_anggota Z ON Z.id_anggota = X.id_anggota WHERE X.`id_anggota`=X.`id_anggota` ;

SELECT * FROM tb_simpanan WHERE id_anggota=id_anggota;

SELECT id_simpanan, tgl_simpan, jenis_simpanan, SUM(jumlah), X.kode_user, X.id_anggota
FROM tb_simpanan X
INNER JOIN tb_anggota Y ON Y.`id_anggota` = X.`id_anggota` WHERE X.`id_anggota` = 'AGT0001' ;

SELECT * FROM tb_anggota;

SELECT id_simpanan, tgl_simpan, jenis_simpanan, jumlah, X.kode_user, X.id_anggota, nama_lengkap 
FROM tb_simpanan X INNER JOIN tb_anggota Y ON Y.id_anggota = X.id_anggota

SELECT * FROM tb_pinjaman
SELECT * FROM slip_pinjaman;

//sebelum dirubah tb_slip_pinjaman_diaplikasi
SELECT  X.id_pinjaman, tgl_pinjam, X.jumlah, bunga, lama_cicilan + cicilan AS lama_cicilan, 
angsuran, hutang, X.kode_user, X.id_anggota, nama_lengkap 
FROM tb_pinjaman X 
INNER JOIN tb_angsuran Y ON Y.id_anggota = X.id_anggota 
INNER JOIN tb_anggota Z ON Z.id_anggota = X.id_anggota

INSERT INTO slip_pinjaman SET id_pinjaman= NEW.id_pin , tgl_pinjam=NEW.tgl_pin, 
	jumlah=NEW.jum , bunga=NEW.bung, lama_cicilan=NEW.lama_cicil, angsuran=NEW.angsur, hutang=NEW.utang,
	kode_user=NEW.kode_us, id_anggota=NEW.id_agt;
	
INSERT INTO slip_pinjaman VALUES(id_pin , tgl_pin, jum , bung, lama_cicil, angsur, utang, kode_us, id_agt);

SELECT id_pin , tgl_pin, jum , bung, lama_cicil, angsur, utang, X.kode_user, X.id_anggota, nama_lengkap
FROM slip_pinjaman X
INNER JOIN tb_anggota Y ON Y.`id_anggota` = X.`id_anggota`;

SELECT * FROM tb_simpanan ;
SELECT * FROM tb_anggota;

SELECT 
CONCAT('Rp. ', FORMAT(simpanan_pokok,0)) AS simpanan_pokok, 
CONCAT('Rp. ', FORMAT(@tot := simpanan_pokok + simpanan_wajib + simpanan_sukarela,0)) AS total, 
CONCAT('Rp. ', FORMAT(SUM(jumlah),0)) AS simpanan,
CONCAT('Rp. ', FORMAT(@tot + SUM(jumlah),0)) AS hasil, 
CONCAT('Rp. ', FORMAT(ROUND(@tot - simpanan_pokok+jumlah),0)) AS kurang
FROM tb_anggota X
INNER JOIN tb_simpanan Y ON Y.id_anggota = X.id_anggota
WHERE X.id_anggota ='AGT0001';

SELECT * FROM tb_penarikan_sim;
SELECT SUM(jumlah) AS jumlah FROM tb_simpanan WHERE id_anggota = 'AGT0001';

SELECT 
CONCAT('Rp. ', FORMAT(min_simpanan,0)) AS min_simpanan, 
CONCAT('Rp. ', FORMAT(max_penarikan,0)) AS max_penarikan, 
CONCAT('Rp. ', FORMAT(min_penarikan,0))  AS min_penarikan 
FROM ketentuan_penarikan

SELECT * FROM ketentuan_penarikan;

SELECT id_penarikan, tgl_penarikan, jumlah, keterangan, X.id_anggota, X.kode_user, nama_lengkap
FROM tb_penarikan_sim X
INNER JOIN tb_anggota Y ON Y.id_anggota = X.id_anggota;

SELECT CONCAT('Rp. ', FORMAT(simpanan_pokok,0)) AS simpanan_pokok, CONCAT('Rp. ', FORMAT(@tot := simpanan_pokok + simpanan_wajib + simpanan_sukarela,0)) AS total, 
CONCAT('Rp. ', FORMAT(SUM(Y.jumlah),0)) AS simpanan, CONCAT('Rp. ', FORMAT(SUM(Z.jumlah),0)) AS tabungan,
CONCAT('Rp. ', FORMAT(@tot + SUM(Y.jumlah),0)) AS hasil, CONCAT('Rp. ', FORMAT(ROUND(@tot - simpanan_pokok + Y.jumlah),0)) AS kurang
FROM tb_anggota X
INNER JOIN tb_simpanan Y ON Y.id_anggota = X.id_anggota
INNER JOIN tb_tabungan Z ON Z.id_anggota = X.id_anggota
WHERE X.id_anggota ='AGT0001'

SELECT * FROM tb_tabungan
SELECT CONCAT('Rp. ', FORMAT(simpanan_pokok,0)) AS simpanan_pokok, 
CONCAT('Rp. ', FORMAT(@tot := simpanan_pokok + simpanan_wajib + simpanan_sukarela,0)) AS total, 
CONCAT('Rp. ', FORMAT(SUM(Y.jumlah),0)) AS simpanan,
CONCAT('Rp. ', FORMAT(@tot + SUM(Y.jumlah),0)) AS hasil, 
CONCAT('Rp. ', FORMAT(ROUND(@tot - simpanan_pokok),0)) AS kurang
FROM tb_anggota X
INNER JOIN tb_simpanan Y ON Y.id_anggota = X.id_anggota
WHERE Y.id_anggota ='AGT0001'

SELECT id_penarikan, tgl_penarikan, jumlah, keterangan, X.id_anggota, X.kode_user, nama_lengkap
FROM tb_persetujuan_pin X
INNER JOIN tb_anggota Y ON Y.id_anggota = X.id_anggota;

SELECT * FROM tb_penarikan_sim;
SELECT * FROM tb_persetujuan_pin;