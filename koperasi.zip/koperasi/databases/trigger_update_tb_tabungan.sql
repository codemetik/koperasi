DELIMITER $$

USE `koperasi`$$

DROP TRIGGER /*!50032 IF EXISTS */ `update_tb_tabungan`$$

CREATE
    /*!50017 DEFINER = 'root'@'localhost' */
    TRIGGER `update_tb_tabungan` AFTER INSERT ON `tb_simpanan` 
    FOR EACH ROW BEGIN
	UPDATE tb_tabungan SET jumlah = jumlah + NEW.jumlah WHERE id_anggota = NEW.id_anggota;
    END;
$$

DELIMITER ;