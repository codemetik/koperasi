DELIMITER $$

USE `koperasi`$$

DROP TRIGGER /*!50032 IF EXISTS */ `update_pinjaman`$$

CREATE
    /*!50017 DEFINER = 'root'@'localhost' */
    TRIGGER `update_pinjaman` AFTER INSERT ON `tb_angsuran` 
    FOR EACH ROW BEGIN
	UPDATE tb_pinjaman SET hutang = hutang-(NEW.jumlah*NEW.cicilan), lama_cicilan = lama_cicilan - NEW.cicilan WHERE id_anggota=NEW.id_anggota;
    END;
$$

DELIMITER ;