DELIMITER $$

USE `koperasi`$$

DROP TRIGGER /*!50032 IF EXISTS */ `delete_persetujuan`$$

CREATE
    /*!50017 DEFINER = 'root'@'localhost' */
    TRIGGER `delete_persetujuan` AFTER INSERT ON `tb_pinjaman` 
    FOR EACH ROW BEGIN
	DELETE FROM tb_persetujuan WHERE id_anggota=NEW.id_anggota;
    END;
$$

DELIMITER ;