-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 23, 2019 at 06:54 AM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 7.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `koperasi`
--

-- --------------------------------------------------------

--
-- Table structure for table `jenis_simpanan`
--

CREATE TABLE `jenis_simpanan` (
  `id_jenis` char(15) NOT NULL,
  `pokok` int(30) NOT NULL,
  `wajib` int(30) NOT NULL,
  `sukarela` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jenis_simpanan`
--

INSERT INTO `jenis_simpanan` (`id_jenis`, `pokok`, `wajib`, `sukarela`) VALUES
('JNS01', 150000, 100000, 25000);

-- --------------------------------------------------------

--
-- Table structure for table `ketentuan_penarikan`
--

CREATE TABLE `ketentuan_penarikan` (
  `id_ket_penarikan` int(15) NOT NULL,
  `min_simpanan` char(30) NOT NULL,
  `max_penarikan` char(30) NOT NULL,
  `min_penarikan` char(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ketentuan_penarikan`
--

INSERT INTO `ketentuan_penarikan` (`id_ket_penarikan`, `min_simpanan`, `max_penarikan`, `min_penarikan`) VALUES
(1, '500000', '10000000', '1000000');

-- --------------------------------------------------------

--
-- Table structure for table `slip_pinjaman`
--

CREATE TABLE `slip_pinjaman` (
  `id_pin` char(15) NOT NULL,
  `tgl_pin` date NOT NULL,
  `jum` char(30) NOT NULL,
  `bung` char(30) NOT NULL,
  `lama_cicil` char(30) NOT NULL,
  `angsur` char(30) NOT NULL,
  `utang` char(30) NOT NULL,
  `kode_user` char(30) NOT NULL,
  `id_anggota` char(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `slip_pinjaman`
--

INSERT INTO `slip_pinjaman` (`id_pin`, `tgl_pin`, `jum`, `bung`, `lama_cicil`, `angsur`, `utang`, `kode_user`, `id_anggota`) VALUES
('0P1P2P6P8P9', '2019-11-10', '4000000', '10', '6', '700000', '4200000', 'USR0001', 'AGT0003'),
('0P2P5P6P8P9', '2019-11-11', '3000000', '10', '6', '525000', '3150000', 'USR0001', 'AGT0001'),
('2P4P5P6P8P9', '2019-11-12', '3000000', '10', '12', '275000', '3300000', 'USR0001', 'AGT0006');

-- --------------------------------------------------------

--
-- Table structure for table `tb_anggota`
--

CREATE TABLE `tb_anggota` (
  `id_anggota` char(15) NOT NULL,
  `kode_user` char(15) NOT NULL,
  `tgl_join` date NOT NULL,
  `nama_lengkap` varchar(30) NOT NULL,
  `alamat` varchar(225) NOT NULL,
  `telephone` char(13) NOT NULL,
  `simpanan_pokok` int(10) NOT NULL,
  `simpanan_wajib` int(10) NOT NULL,
  `simpanan_sukarela` int(10) NOT NULL,
  `saldo` int(10) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_anggota`
--

INSERT INTO `tb_anggota` (`id_anggota`, `kode_user`, `tgl_join`, `nama_lengkap`, `alamat`, `telephone`, `simpanan_pokok`, `simpanan_wajib`, `simpanan_sukarela`, `saldo`, `status`) VALUES
('AGT0001', 'USR0001', '2019-11-01', 'ramlan', 'Depok', '089661117770', 150000, 100000, 25000, 275000, 'non karyawan'),
('AGT0002', 'USR0001', '2019-11-02', 'icha', 'Pamulang', '089661117771', 150000, 100000, 25000, 275000, 'non karyawan'),
('AGT0003', 'USR0001', '2019-11-04', 'Andi Nugroho', 'Jakarta', '089661117772', 150000, 100000, 25000, 275000, 'non karyawan'),
('AGT0004', 'USR0001', '2019-11-05', 'Dandi Faniyah', 'Pamulang', '089661117772', 150000, 100000, 25000, 275000, 'non karyawan'),
('AGT0005', 'USR0001', '2019-11-06', 'Bimbim', 'Depok', '089661117775', 150000, 100000, 25000, 275000, 'non karyawan'),
('AGT0006', 'USR0001', '2019-11-07', 'Kaka Akhadi Setiawan', 'Jakarta', '089661117774', 150000, 100000, 25000, 275000, 'non karyawan');

--
-- Triggers `tb_anggota`
--
DELIMITER $$
CREATE TRIGGER `insert_tb_tabungan` AFTER INSERT ON `tb_anggota` FOR EACH ROW BEGIN
	insert into tb_tabungan set jumlah = NEW.saldo, id_anggota= NEW.id_anggota, kode_user= NEW.kode_user;
    END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tb_angsuran`
--

CREATE TABLE `tb_angsuran` (
  `no_pengembalian` varchar(20) NOT NULL,
  `tgl_bayar` date NOT NULL,
  `jumlah` int(20) NOT NULL,
  `sisa_pinjaman` int(20) NOT NULL,
  `cicilan` int(20) NOT NULL,
  `keterangan` varchar(225) NOT NULL,
  `kode_user` char(15) NOT NULL,
  `id_pinjaman` char(15) NOT NULL,
  `id_anggota` char(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_angsuran`
--

INSERT INTO `tb_angsuran` (`no_pengembalian`, `tgl_bayar`, `jumlah`, `sisa_pinjaman`, `cicilan`, `keterangan`, `kode_user`, `id_pinjaman`, `id_anggota`) VALUES
('ASRN0001', '2019-11-23', 700000, 3500000, 1, 'Sudah Bayar', 'USR0001', '0P1P2P6P8P9', 'AGT0003'),
('ASRN0002', '2019-11-23', 700000, 2800000, 1, 'Sudah Bayar', 'USR0001', '0P1P2P6P8P9', 'AGT0003'),
('ASRN0003', '2019-11-23', 700000, 2100000, 1, 'Sudah Bayar', 'USR0001', '0P1P2P6P8P9', 'AGT0003'),
('ASRN0004', '2019-11-23', 275000, 3025000, 1, 'Sudah Bayar', 'USR0001', '2P4P5P6P8P9', 'AGT0006'),
('ASRN0005', '2019-11-23', 275000, 2750000, 1, 'Sudah Bayar', 'USR0001', '2P4P5P6P8P9', 'AGT0006'),
('ASRN0006', '2019-11-23', 275000, 2475000, 1, 'Sudah Bayar', 'USR0001', '2P4P5P6P8P9', 'AGT0006');

--
-- Triggers `tb_angsuran`
--
DELIMITER $$
CREATE TRIGGER `update_pinjaman` AFTER INSERT ON `tb_angsuran` FOR EACH ROW BEGIN
	UPDATE tb_pinjaman SET hutang = hutang-(NEW.jumlah*NEW.cicilan), lama_cicilan = lama_cicilan - NEW.cicilan WHERE id_anggota=NEW.id_anggota;
    END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tb_penarikan_sim`
--

CREATE TABLE `tb_penarikan_sim` (
  `id_penarikan` char(15) NOT NULL,
  `tgl_penarikan` datetime NOT NULL,
  `jumlah` int(30) NOT NULL,
  `keterangan` varchar(225) NOT NULL,
  `id_anggota` char(30) NOT NULL,
  `kode_user` char(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_persetujuan`
--

CREATE TABLE `tb_persetujuan` (
  `id_pinjam` char(15) NOT NULL,
  `tgl_pinjam` datetime NOT NULL,
  `jumlah` int(10) NOT NULL,
  `bunga` int(10) NOT NULL,
  `lama_cicilan` int(10) NOT NULL,
  `angsuran` int(10) NOT NULL,
  `hutang` int(10) NOT NULL,
  `kode_user` char(15) NOT NULL,
  `id_anggota` char(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_persetujuan`
--

INSERT INTO `tb_persetujuan` (`id_pinjam`, `tgl_pinjam`, `jumlah`, `bunga`, `lama_cicilan`, `angsuran`, `hutang`, `kode_user`, `id_anggota`) VALUES
('PIN0001', '2019-11-23 11:28:30', 1500000, 10, 6, 262500, 1575000, 'USR0001', 'AGT0002'),
('PIN0003', '2019-11-23 11:31:49', 3000000, 10, 6, 525000, 3150000, 'USR0001', 'AGT0004'),
('PIN0004', '2019-11-23 11:46:30', 3500000, 10, 12, 320833, 3850000, 'USR0001', 'AGT0005');

-- --------------------------------------------------------

--
-- Table structure for table `tb_persetujuan_pin`
--

CREATE TABLE `tb_persetujuan_pin` (
  `id_penarikan` char(15) NOT NULL,
  `tgl_penarikan` date NOT NULL,
  `jumlah` int(30) NOT NULL,
  `keterangan` varchar(225) NOT NULL,
  `id_anggota` char(30) NOT NULL,
  `kode_user` char(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_persetujuan_pin`
--

INSERT INTO `tb_persetujuan_pin` (`id_penarikan`, `tgl_penarikan`, `jumlah`, `keterangan`, `id_anggota`, `kode_user`) VALUES
('0W2W4W5W7W8', '2019-11-23', 1500000, 'tarik tunai', 'AGT0002', 'USR0001'),
('1W3W6W7W8W9', '2019-11-23', 1200000, 'tarik tunai', 'AGT0001', 'USR0001');

--
-- Triggers `tb_persetujuan_pin`
--
DELIMITER $$
CREATE TRIGGER `delete_tb_penarikan_sim` AFTER INSERT ON `tb_persetujuan_pin` FOR EACH ROW BEGIN
	delete from tb_penarikan_sim where id_anggota = NEW.id_anggota;
    END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `insert_tb_persetujuan_sim` BEFORE INSERT ON `tb_persetujuan_pin` FOR EACH ROW BEGIN
	UPDATE tb_tabungan SET jumlah = jumlah - NEW.jumlah WHERE id_anggota= NEW.id_anggota;
    END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tb_pinjaman`
--

CREATE TABLE `tb_pinjaman` (
  `id_pinjaman` char(15) NOT NULL,
  `tgl_pinjam` date NOT NULL,
  `jumlah` char(30) NOT NULL,
  `bunga` char(30) NOT NULL,
  `lama_cicilan` char(30) NOT NULL,
  `angsuran` char(30) NOT NULL,
  `hutang` char(30) NOT NULL,
  `kode_user` char(30) NOT NULL,
  `id_anggota` char(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_pinjaman`
--

INSERT INTO `tb_pinjaman` (`id_pinjaman`, `tgl_pinjam`, `jumlah`, `bunga`, `lama_cicilan`, `angsuran`, `hutang`, `kode_user`, `id_anggota`) VALUES
('0P1P2P6P8P9', '2019-11-10', '4000000', '10', '3', '700000', '2100000', 'USR0001', 'AGT0003'),
('0P2P5P6P8P9', '2019-11-11', '3000000', '10', '6', '525000', '3150000', 'USR0001', 'AGT0001'),
('2P4P5P6P8P9', '2019-11-12', '3000000', '10', '9', '275000', '2475000', 'USR0001', 'AGT0006');

--
-- Triggers `tb_pinjaman`
--
DELIMITER $$
CREATE TRIGGER `delete_persetujuan` AFTER INSERT ON `tb_pinjaman` FOR EACH ROW BEGIN
	DELETE FROM tb_persetujuan WHERE id_anggota=NEW.id_anggota;
    END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tb_simpanan`
--

CREATE TABLE `tb_simpanan` (
  `id_simpanan` char(15) NOT NULL,
  `tgl_simpan` date NOT NULL,
  `jenis_simpanan` varchar(30) NOT NULL,
  `jumlah` int(10) NOT NULL,
  `kode_user` char(15) NOT NULL,
  `id_anggota` char(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_simpanan`
--

INSERT INTO `tb_simpanan` (`id_simpanan`, `tgl_simpan`, `jenis_simpanan`, `jumlah`, `kode_user`, `id_anggota`) VALUES
('SMPN0001', '2019-11-02', 'Wajib', 100000, 'USR0001', 'AGT0001'),
('SMPN0002', '2019-11-23', 'Sukarela', 25000, 'USR0001', 'AGT0001'),
('SMPN0003', '2019-11-23', 'Sukarela', 1500000, 'USR0001', 'AGT0001'),
('SMPN0004', '2019-11-02', 'Wajib', 100000, 'USR0001', 'AGT0001'),
('SMPN0005', '2019-11-23', 'Wajib', 100000, 'USR0001', 'AGT0002'),
('SMPN0006', '2019-11-23', 'Wajib', 100000, 'USR0001', 'AGT0003'),
('SMPN0007', '2019-11-23', 'Wajib', 100000, 'USR0001', 'AGT0004'),
('SMPN0008', '2019-11-23', 'Wajib', 100000, 'USR0001', 'AGT0005'),
('SMPN0009', '2019-11-23', 'Wajib', 100000, 'USR0001', 'AGT0006'),
('SMPN0010', '2019-11-23', 'Sukarela', 3000000, 'USR0001', 'AGT0002'),
('SMPN0011', '2019-11-23', 'Wajib', 100000, 'USR0001', 'AGT0003'),
('SMPN0012', '2019-11-23', 'Sukarela', 2000000, 'USR0001', 'AGT0003'),
('SMPN0013', '2019-11-23', 'Sukarela', 2000000, 'USR0001', 'AGT0004');

--
-- Triggers `tb_simpanan`
--
DELIMITER $$
CREATE TRIGGER `update_tb_tabungan` AFTER INSERT ON `tb_simpanan` FOR EACH ROW BEGIN
	update tb_tabungan set jumlah = jumlah + NEW.jumlah where id_anggota = NEW.id_anggota;
    END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tb_tabungan`
--

CREATE TABLE `tb_tabungan` (
  `id_tabungan` int(11) NOT NULL,
  `jumlah` int(30) NOT NULL,
  `id_anggota` char(30) NOT NULL,
  `kode_user` char(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_tabungan`
--

INSERT INTO `tb_tabungan` (`id_tabungan`, `jumlah`, `id_anggota`, `kode_user`) VALUES
(17, 800000, 'AGT0001', 'USR0001'),
(18, 1875000, 'AGT0002', 'USR0001'),
(19, 2475000, 'AGT0003', 'USR0001'),
(20, 2375000, 'AGT0004', 'USR0001'),
(21, 375000, 'AGT0005', 'USR0001'),
(22, 375000, 'AGT0006', 'USR0001');

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `kode_user` char(15) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(225) NOT NULL,
  `nama_user` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`kode_user`, `username`, `password`, `nama_user`) VALUES
('USR0001', 'admin', '$2y$10$9ZftcLWU6oU8iTHzLKEDpeDZKUDb1dhTp7LzqKghknN7wAgdnSFby', 'adil'),
('USR0002', 'admin123', '$2y$10$y/TAOs7U1Xbiuv4w7ePYFOhl7dJcHGqBh4UQLLCvcdGchDR8MbMp6', 'anam'),
('USR0003', 'andi', '$2y$10$ZuCXc6D8irtzTY86OkGNzukWzHrKPsX3/NVrr7radaXuN4p.w81py', 'andi');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `jenis_simpanan`
--
ALTER TABLE `jenis_simpanan`
  ADD PRIMARY KEY (`id_jenis`);

--
-- Indexes for table `ketentuan_penarikan`
--
ALTER TABLE `ketentuan_penarikan`
  ADD PRIMARY KEY (`id_ket_penarikan`);

--
-- Indexes for table `slip_pinjaman`
--
ALTER TABLE `slip_pinjaman`
  ADD PRIMARY KEY (`id_pin`),
  ADD KEY `id_anggota` (`id_anggota`);

--
-- Indexes for table `tb_anggota`
--
ALTER TABLE `tb_anggota`
  ADD PRIMARY KEY (`id_anggota`),
  ADD KEY `r_anggota` (`kode_user`);

--
-- Indexes for table `tb_angsuran`
--
ALTER TABLE `tb_angsuran`
  ADD PRIMARY KEY (`no_pengembalian`),
  ADD KEY `r_pengembalian` (`kode_user`),
  ADD KEY `r_angsuran` (`id_pinjaman`);

--
-- Indexes for table `tb_penarikan_sim`
--
ALTER TABLE `tb_penarikan_sim`
  ADD PRIMARY KEY (`id_penarikan`),
  ADD KEY `id_anggota` (`id_anggota`);

--
-- Indexes for table `tb_persetujuan`
--
ALTER TABLE `tb_persetujuan`
  ADD PRIMARY KEY (`id_pinjam`),
  ADD KEY `r_anggotaan` (`id_anggota`);

--
-- Indexes for table `tb_persetujuan_pin`
--
ALTER TABLE `tb_persetujuan_pin`
  ADD PRIMARY KEY (`id_penarikan`),
  ADD KEY `id_anggota` (`id_anggota`);

--
-- Indexes for table `tb_pinjaman`
--
ALTER TABLE `tb_pinjaman`
  ADD PRIMARY KEY (`id_pinjaman`),
  ADD KEY `id_anggota` (`id_anggota`);

--
-- Indexes for table `tb_simpanan`
--
ALTER TABLE `tb_simpanan`
  ADD PRIMARY KEY (`id_simpanan`),
  ADD KEY `r_simpanan` (`id_anggota`),
  ADD KEY `r_user` (`kode_user`);

--
-- Indexes for table `tb_tabungan`
--
ALTER TABLE `tb_tabungan`
  ADD PRIMARY KEY (`id_tabungan`),
  ADD KEY `id_anggota` (`id_anggota`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`kode_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_tabungan`
--
ALTER TABLE `tb_tabungan`
  MODIFY `id_tabungan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `slip_pinjaman`
--
ALTER TABLE `slip_pinjaman`
  ADD CONSTRAINT `slip_pinjaman_ibfk_1` FOREIGN KEY (`id_anggota`) REFERENCES `tb_pinjaman` (`id_anggota`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tb_anggota`
--
ALTER TABLE `tb_anggota`
  ADD CONSTRAINT `r_anggota` FOREIGN KEY (`kode_user`) REFERENCES `tb_user` (`kode_user`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `tb_angsuran`
--
ALTER TABLE `tb_angsuran`
  ADD CONSTRAINT `r_angsuran` FOREIGN KEY (`id_pinjaman`) REFERENCES `tb_pinjaman` (`id_pinjaman`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `r_pengembalian` FOREIGN KEY (`kode_user`) REFERENCES `tb_user` (`kode_user`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `tb_penarikan_sim`
--
ALTER TABLE `tb_penarikan_sim`
  ADD CONSTRAINT `tb_penarikan_sim_ibfk_1` FOREIGN KEY (`id_anggota`) REFERENCES `tb_anggota` (`id_anggota`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `tb_persetujuan`
--
ALTER TABLE `tb_persetujuan`
  ADD CONSTRAINT `r_anggotaan` FOREIGN KEY (`id_anggota`) REFERENCES `tb_anggota` (`id_anggota`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `tb_persetujuan_pin`
--
ALTER TABLE `tb_persetujuan_pin`
  ADD CONSTRAINT `tb_persetujuan_pin_ibfk_1` FOREIGN KEY (`id_anggota`) REFERENCES `tb_anggota` (`id_anggota`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `tb_pinjaman`
--
ALTER TABLE `tb_pinjaman`
  ADD CONSTRAINT `tb_pinjaman_ibfk_1` FOREIGN KEY (`id_anggota`) REFERENCES `tb_anggota` (`id_anggota`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `tb_simpanan`
--
ALTER TABLE `tb_simpanan`
  ADD CONSTRAINT `r_simpanan` FOREIGN KEY (`id_anggota`) REFERENCES `tb_anggota` (`id_anggota`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `r_user` FOREIGN KEY (`kode_user`) REFERENCES `tb_user` (`kode_user`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `tb_tabungan`
--
ALTER TABLE `tb_tabungan`
  ADD CONSTRAINT `tb_tabungan_ibfk_1` FOREIGN KEY (`id_anggota`) REFERENCES `tb_anggota` (`id_anggota`) ON DELETE CASCADE ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
