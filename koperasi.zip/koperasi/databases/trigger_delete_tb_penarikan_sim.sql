DELIMITER $$

USE `koperasi`$$

DROP TRIGGER /*!50032 IF EXISTS */ `delete_tb_penarikan_sim`$$

CREATE
    /*!50017 DEFINER = 'root'@'localhost' */
    TRIGGER `delete_tb_penarikan_sim` AFTER INSERT ON `tb_persetujuan_pin` 
    FOR EACH ROW BEGIN
	DELETE FROM tb_penarikan_sim WHERE id_anggota = NEW.id_anggota;
    END;
$$

DELIMITER ;