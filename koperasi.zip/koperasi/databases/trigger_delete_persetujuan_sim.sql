DELIMITER $$

USE `koperasi`$$

DROP TRIGGER /*!50032 IF EXISTS */ `insert_tb_persetujuan_sim`$$

CREATE
    /*!50017 DEFINER = 'root'@'localhost' */
    TRIGGER `insert_tb_persetujuan_sim` BEFORE INSERT ON `tb_persetujuan_pin` 
    FOR EACH ROW BEGIN
	UPDATE tb_tabungan SET jumlah = jumlah - NEW.jumlah WHERE id_anggota= NEW.id_anggota;
    END;
$$

DELIMITER ;