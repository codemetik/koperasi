<?php 
session_start();

if (!isset($_SESSION['login'])) {
  header("Location:../login.php");
}
include "../../koneksi/koneksi.php";

$query1 = mysqli_query($koneksi, "SELECT * FROM tb_anggota");
$data0 = mysqli_num_rows($query1);

$query2 = mysqli_query($koneksi, "SELECT CONCAT('Rp. ', FORMAT(SUM(simpanan_pokok + simpanan_wajib + simpanan_sukarela),0)) AS tabungan FROM tb_anggota");
$data1= mysqli_fetch_array($query2);

$query3 = mysqli_query($koneksi, "SELECT * FROM tb_simpanan");
$data2 = mysqli_num_rows($query3);

$query4 = mysqli_query($koneksi, "SELECT CONCAT('Rp. ', FORMAT(SUM(jumlah),0)) AS jumlah FROM tb_simpanan");
$data3 = mysqli_fetch_array($query4);

$query5 = mysqli_query($koneksi, " SELECT * FROM tb_pinjaman");
$data4 = mysqli_num_rows($query5);
$query6 = mysqli_query($koneksi, "SELECT CONCAT('Rp. ', FORMAT(SUM(hutang),0)) AS hutang FROM tb_pinjaman");
$data5 = mysqli_fetch_array($query6);
$query7 =mysqli_query($koneksi, "SELECT * FROM tb_angsuran");
$data6 = mysqli_num_rows($query7);
$query8 = mysqli_query($koneksi, "SELECT CONCAT('Rp. ', FORMAT(SUM(sisa_pinjaman),0)) AS sisa_pinjaman FROM tb_angsuran");
$data7 = mysqli_fetch_array($query8);

$query9 = mysqli_query($koneksi, "SELECT * FROM tb_persetujuan_pin");
$data8 = mysqli_num_rows($query9);

$query = mysqli_query($koneksi, "SELECT max(id_pinjam) AS maxkode FROM tb_persetujuan");
$data = mysqli_fetch_array($query);
$kdPinjam = $data['maxkode'];
$noUrut = (int)substr($kdPinjam, 3, 4);
$noUrut++;
$char = "PIN";
$kdPinjam = $char . sprintf("%04s", $noUrut); 

$tanggal = date("Y-m-d H:i:s");

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <link rel="icon" type="image/png" href="../../img/logo_kp_indonesia.png">
  <title>Koperasi | Cipta Harapan</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>
<body class="hold-transition sidebar-mini layout-navbar-fixed">
<!-- Site wrapper -->
<div class="wrapper">
  <?php include "navbar.php"; ?>
  <?php 
    $use = $_SESSION['user'];
    $qr = mysqli_query($koneksi, "SELECT * FROM tb_user WHERE nama_user = '$use'");
$user = mysqli_fetch_assoc($qr);
  ?>
  <?php include "sidebar_content.php"; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-warning">
              <div class="inner">
                <h3><?php echo $data0; ?></h3>

                <p>Anggota</p>
              </div>
              <div class="icon">

              </div>
              <a href="laporan_anggota.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-info">
              <div class="inner">
                <h3><?php echo $data2; ?></h3>

                <p>Simpanan</p>
              </div>
              <div class="icon">

              </div>
              <a href="laporan_simpanan.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-success">
              <div class="inner">
                <h3><?php echo $data4; ?></h3>

                <p>Pinjaman</p>
              </div>
              <div class="icon">

              </div>
              <a href="laporan_pinjaman.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-danger">
              <div class="inner">
                <h3><?php echo $data6; ?></h3>

                <p>Setoran</p>
              </div>
              <div class="icon">

              </div>
              <a href="laporan_setoran.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-md-12 col-6">
            <!-- small box -->
            <div class="small-box bg-dark">
              <div class="inner">
                <h3><?php echo $data8; ?></h3>

                <p>Penarikan Simpanan</p>
              </div>
              <div class="icon">

              </div>
              <a href="laporan_penarikan.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!--Code Mysqli Disini-->
      </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <?php include "../../footer.php"; ?>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->
<!--script-->
  <script type="text/javascript">
    function klik() {
      var jum = parseInt(document.getElementById('jumlah').value);
      var bung = parseInt(document.getElementById('bunga').value);
      var cicil = parseInt(document.getElementById('cicil').value);
      
      var hasil = Math.round((bung/100)*(cicil/12)*jum);
      var has = jum+hasil;
      var cari_angsur = Math.round(has/cicil);
      document.getElementById('angsuran').value = cari_angsur;
      document.getElementById('hutang').value = has;

    }
  </script>
<!--/script-->

<!-- jQuery -->
<script src="../../plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../../dist/js/demo.js"></script>
</body>
</html>