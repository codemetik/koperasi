<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <link rel="icon" type="image/png" href="../../img/logo_kp_indonesia.png">
  <title>Koperasi | Cipta Harapan Jaya</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>
<body class="hold-transition sidebar-mini sidebar-collapse">
<!-- Site wrapper -->
<div class="wrapper">

  <!-- Main Sidebar Container -->


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="card-body table-responsive p-0" style="height: 600px;">
                <table class="table table-head-fixed">
                  <thead class="text-center">
                    <tr>
                      <th>ID SIMPANAN</th>
                      <th>Tanggal Simpan</th>
                      <th>Jenis Simpanan</th>
                      <th>Jumlah</th>
                      <th>Kode User</th>
                      <th>ID Angoota</th>
                      <th>Nama Anggota</th>
                    </tr>
                  </thead>
                  <?php 
                    include "../../koneksi/koneksi.php";
                      $awal = $_GET['awal'];
                      $akhir = $_GET['akhir'];
                      $query = mysqli_query($koneksi, "SELECT id_simpanan, tgl_simpan, jenis_simpanan, jumlah, X.kode_user, X.id_anggota, nama_lengkap FROM tb_simpanan X INNER JOIN tb_anggota Y ON Y.id_anggota = X.id_anggota WHERE tgl_simpan BETWEEN '".$awal."' AND '".$akhir."'");
                    
                    while ($data = mysqli_fetch_array($query)) {
                  ?>
                  <tbody class="text-center">
                    <tr>
                      <td><?php echo $data['id_simpanan']; ?></td>
                      <td><?php echo $data['tgl_simpan']; ?></td>
                      <td><?php echo $data['jenis_simpanan']; ?></td>
                      <td><?php echo $data['jumlah']; ?></td>
                      <td><?php echo $data['kode_user']; ?></td>
                      <td><?php echo $data['id_anggota']; ?></td>
                      <td><?php echo $data['nama_lengkap']; ?></td>
                    <?php } ?>
                    </tr>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
      </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>Version</b> 0.0.0
    </div>
    <strong>Copyright &copy; 2019 <a href="#">Cipta Harapan Jaya</a></strong>
  </footer>

  
</div>
<!-- ./wrapper -->
<script type="text/javascript">
  window.print();
</script>
<!-- jQuery -->
<script src="../../plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../../dist/js/demo.js"></script>
</body>
</html>
