<?php 
session_start();

if (!isset($_SESSION['login'])) {
  header("Location:../login.php");
}
include "../../koneksi/koneksi.php";

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <link rel="icon" type="image/png" href="../../img/logo_kp_indonesia.png">
  <title>Koperasi | Cipta Harapan</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>
<body class="hold-transition sidebar-mini layout-navbar-fixed">
<!-- Site wrapper -->
<div class="wrapper">
  <?php include "navbar.php"; ?>
  <?php 
    $use = $_SESSION['user'];
    $qr = mysqli_query($koneksi, "SELECT * FROM tb_user WHERE nama_user = '$use'");
$user = mysqli_fetch_assoc($qr);
$jenis = mysqli_query($koneksi, "SELECT * FROM jenis_simpanan");
$jens = mysqli_fetch_array($jenis);
  ?>
  <?php include "sidebar_content.php"; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Data Pinjaman</h3>

                <div class="card-tools">
                  <form action="laporan_pinjaman.php" method="GET">
                  <div class="input-group" style="width: 650px;">
                    <input type="date" name="awal" class="form-control mr-3" placeholder="Search">
                    <input type="date" name="akhir" class="form-control mr-3" placeholder="Search">
                    <button type="submit" class="btn btn-primary mr-3">Tampilkan</button>
                    
                    <a href="laporan_pinjaman.php" class="btn btn-primary">Refresh</a>
                  
                    
                  </div>
                  </form>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0" style="height: 600px;">
                <table class="table table-head-fixed">
                  <thead class="text-center">
                    <tr>
                      <th>ID PINJAMAN</th>
                      <th>Tanggal Pinjam</th>
                      <th>Jumlah</th>
                      <th>Bunga</th>
                      <th>Lama Cicilan</th>
                      <th>Angsuran / Bulan</th>
                      <th>Hutang</th>
                      <th>Kode User</th>
                      <th>ID Anggota</th>
                      <th>Nama Anggota</th>
                    </tr>
                  </thead>
                  <?php 
                    include "../../koneksi/koneksi.php";
                    if (isset($_GET['awal']) && isset($_GET['akhir'])) {
                      $awal = $_GET['awal'];
                      $akhir = $_GET['akhir'];
                      $query = mysqli_query($koneksi, "SELECT id_pin , tgl_pin, CONCAT('Rp. ',FORMAT(jum,0)) AS jum , bung, lama_cicil, CONCAT('Rp. ', FORMAT(angsur,0)) AS angsur, CONCAT('Rp. ', FORMAT(utang,0)) AS utang, X.kode_user, X.id_anggota, nama_lengkap FROM slip_pinjaman X INNER JOIN tb_anggota Y ON Y.id_anggota = X.id_anggota WHERE tgl_pin BETWEEN '".$awal."' AND '".$akhir."'");
                    }else{
                    $query = mysqli_query($koneksi, "SELECT id_pin , tgl_pin, CONCAT('Rp. ',FORMAT(jum,0)) AS jum , bung, lama_cicil, CONCAT('Rp. ', FORMAT(angsur,0)) AS angsur, CONCAT('Rp. ', FORMAT(utang,0)) AS utang, X.kode_user, X.id_anggota, nama_lengkap FROM slip_pinjaman X INNER JOIN tb_anggota Y ON Y.id_anggota = X.id_anggota");
                  }
                    while ($data = mysqli_fetch_array($query)) {
                  ?>
                  <tbody class="text-center">
                    <tr>
                      <td><?php echo $data['id_pin']; ?></td>
                      <td><?php echo $data['tgl_pin']; ?></td>
                      <td><?php echo $data['jum']; ?></td>
                      <td><?php echo $data['bung']; ?></td>
                      <td><?php echo $data['lama_cicil']; ?></td>
                      <td><?php echo $data['angsur']; ?></td>
                      <td><?php echo $data['utang']; ?></td>
                      <td><?php echo $data['kode_user']; ?></td>
                      <td><?php echo $data['id_anggota']; ?></td>
                      <td><?php echo $data['nama_lengkap']; ?></td>
                    <?php } ?>
                    </tr>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <a href="print_lap_pinjaman.php?awal=<?php echo $awal; ?>&akhir=<?php echo $akhir; ?>" class="btn btn-primary mr-3" target="_BLANK"><i class="fas fa-print"></i>Print</a>
      </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <?php include "../../footer.php"; ?>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="../../plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../../dist/js/demo.js"></script>
</body>
</html>