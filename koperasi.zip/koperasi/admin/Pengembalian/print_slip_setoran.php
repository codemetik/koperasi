<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <link rel="icon" type="image/png" href="../../img/logo_kp_indonesia.png">
  <title>Koperasi | Cipta Harapan Jaya</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>
<body class="hold-transition sidebar-mini sidebar-collapse">
<!-- Site wrapper -->
<div class="wrapper">

  <!-- Main Sidebar Container -->


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
      <?php 
      include "../../koneksi/koneksi.php";
      $id = $_GET['id'];
      $query = mysqli_query($koneksi, "SELECT no_pengembalian, tgl_bayar, CONCAT('Rp. ',FORMAT(X.jumlah,0)) AS jumlah, CONCAT('Rp. ', FORMAT(sisa_pinjaman,0)) AS sisa_pinjaman, cicilan, CONCAT('Rp. ', FORMAT(X.jumlah*cicilan,0)) AS total, keterangan, X.kode_user, X.id_pinjaman, X.id_anggota, nama_lengkap FROM tb_angsuran X INNER JOIN tb_pinjaman Y ON Y.id_anggota = X.id_anggota INNER JOIN tb_anggota Z ON Z.id_anggota = X.id_anggota WHERE X.no_pengembalian = '".$id."'");
      $data = mysqli_fetch_array($query);
      ?>
        <div class="card-header bg-dark">
        <div class="text-center">
          <h3>SLIP SETORAN </h3>
          <h3>Cipta Harapan Jaya</h3>
          <hr>
        </div>
        </div>
        <table class="table">
          <tr>
            <th>Nama  Lengkap</th>
            <td>: <?php echo $data['nama_lengkap']; ?></td>
          </tr>
          <tr>
            <th>No Pengembalian</th>
            <td>: <?php echo $data['no_pengembalian']; ?></td>
          </tr>
          <tr>
            <th>TGL Bayar</th>
            <td>: <?php echo $data['tgl_bayar']; ?></td>
          </tr>
          <tr>
            <th>Jumlah</th>
            <td>: <?php echo $data['jumlah'];  ?> </td>
          </tr>
          <tr>
            <th>Sisa Pinjaman</th>
            <td>: <?php echo $data['sisa_pinjaman']; ?></td>
          </tr>
          <tr>
            <th>Cicilan</th>
            <td>: <?php echo $data['cicilan']; ?> bulan</td>
          </tr>
          <tr>
            <th>Total</th>
            <td>: <?php echo $data['total']; ?></td>
          </tr>
          <tr>
            <th>Keterangan</th>
            <td>: <?php echo $data['keterangan']; ?></td>
          </tr>
          <tr>
            <th>Kode User</th>
            <td>: <?php echo $data['kode_user']; ?></td>
          </tr>
          <tr>
            <th>ID Pinjaman</th>
            <td>: <?php echo $data['id_pinjaman']; ?></td>
          </tr>
          <tr>
            <th>ID Anggota</th>
            <td>: <?php echo $data['id_anggota']; ?></td>
          </tr>
          
        </table>
      </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>Version</b> 0.0.0
    </div>
    <strong>Copyright &copy; 2019 <a href="#">Cipta Harapan Jaya</a></strong>
  </footer>

  
</div>
<!-- ./wrapper -->
<script type="text/javascript">
  window.print();
</script>
<!-- jQuery -->
<script src="../../plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../../dist/js/demo.js"></script>
</body>
</html>
