<!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="../dasboard.php" class="brand-link elevation-4">
      <img src="../../img/logo_kp_indonesia.png"
           alt="AdminLTE Logo"
           class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light">Cipta Harapan Jaya</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Anggota
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="../Anggota-baru/registrasi.php" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Registrasi</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="../Anggota-baru/data_anggota.php" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Data Anggota</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="../Anggota-baru/kartu_anggota.php" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Kartu Anggota</p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-chart-pie"></i>
              <p>
                Tabungan
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="../Tabungan/simpanan.php" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Simpan</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="../Tabungan/data_simpanan.php" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Data Simpanan</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="../Tabungan/penarikan_simpanan.php" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Penarikan Simpanan</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="../Tabungan/persetujuan_penarikan.php" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Persetujuan Penarikan</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="../Tabungan/data_penarikan.php" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Data Penarikan</p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-tree"></i>
              <p>
                Pinjaman
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="../Pinjaman/pinjam.php" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Pinjam</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="../Pinjaman/persetujuan_pinjaman.php" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Persetujuan Pinjaman</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="../Pinjaman/data_pinjaman.php" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Data Pinjaman</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="../Pinjaman/slip_pinjaman.php" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Slip Pinjaman</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="../Pinjaman/kartu_pinjaman.php" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Kartu Pinjaman</p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-edit"></i>
              <p>
                Pengembalian
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="setor.php" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Setor</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="laporan_setoran.php" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Laporan Setoran</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="slip_setoran.php" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Slip Setoran</p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-table"></i>
              <p>
                Laporan
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              
              
              <li class="nav-item">
                <a href="../Kartu/buku_tabungan.php" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Laporan</p>
                </a>
              </li>
            </ul>
          </li>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>