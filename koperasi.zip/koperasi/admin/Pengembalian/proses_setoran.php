<?php 

include "../../koneksi/koneksi.php";

if (isset($_POST['save'])) {

	$no_pengembalian = $_POST['no_pengembalian'];
	$tgl_bayar = $_POST['tgl_bayar'];
	$jumlah = $_POST['jumlah'];
	$sisa_pinjaman = $_POST['sisa_pinjaman'];
	$cicilan = $_POST['cicil'];
	$ket = htmlspecialchars($_POST['ket']);
	$kode_user =$_POST['kode_user'];
	$id_pinj = $_POST['id_pinj'];
	$id_agt = $_POST['id_agt'];

if (!empty($no_pengembalian)&&!empty($cicilan)&&!empty($ket)) {
	$kali = $jumlah*$cicilan; 
	$hasil = $sisa_pinjaman-$kali;
	$query = mysqli_query($koneksi, "INSERT INTO tb_angsuran(no_pengembalian, tgl_bayar, jumlah, sisa_pinjaman, cicilan, keterangan, kode_user, id_pinjaman, id_anggota) VALUES('$no_pengembalian','$tgl_bayar','$jumlah','$hasil','$cicilan','$ket','$kode_user','$id_pinj','$id_agt')");
	if ($query) {
		echo "<script>
			alert('Uang Berhasil di Setor');
			document.location.href = 'laporan_setoran.php';
		</script>";
	}
}else{
	echo "<script>
			alert('Maaf anda harus melengkapi isian form');
			document.location.href = 'setor.php';
		</script>";
}
}
?>
