<?php 
session_start();

if (!isset($_SESSION['login'])) {
  header("Location:../login.php");
}

include "../../koneksi/koneksi.php";

$query = mysqli_query($koneksi, "SELECT max(id_simpanan) AS maxkode FROM tb_simpanan");
$data = mysqli_fetch_array($query);
$id_simpan = $data['maxkode'];
$noUrut = (int)substr($id_simpan, 4, 4);
$noUrut++;
$char = "SMPN";
$id_simpan = $char . sprintf("%04s", $noUrut); 

date_default_timezone_set('Asia/Jakarta');
$tanggal = date("Y-m-d H:i:s");

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <link rel="icon" type="image/png" href="../../img/logo_kp_indonesia.png">
  <title>Koperasi | Cipta Harapan Jaya</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>
<body class="hold-transition sidebar-mini layout-navbar-fixed">
<!-- Site wrapper -->
<div class="wrapper">
  <?php include "navbar.php"; ?>
  <?php 
    $use = $_SESSION['user'];
    $qr = mysqli_query($koneksi, "SELECT * FROM tb_user WHERE nama_user = '$use'");
$user = mysqli_fetch_assoc($qr);

$J_smpn = mysqli_query($koneksi, "SELECT * FROM jenis_simpanan");
$j = mysqli_fetch_array($J_smpn);
  ?>
  <?php include "sidebar_content.php"; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <form role ="form" action="proses_simpanan.php" method="post">
        <div class="row">
          <div class="col-md-6">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Penyimpanan</h3>
              </div>
              <!-- /.card-header -->

                <div class="card-body">
                  <div class="col-sm-6">
                      <div class="form-group">
                        <label>ID simpanan</label>
                        <input type="text" class="form-control" name="id_simpanan" value="<?php echo $id_simpan; ?>" placeholder="id anggota ..." readonly>
                      </div>
                  </div>
                  <div class="form-group">
                    <label class="col-form-label" for="inputSuccess">Tanggal Simpan</label>
                    <input type="text" class="form-control" name="tgl_simpan" value="<?php echo $tanggal; ?>" placeholder="tanggal join ...">
                  </div><hr>
                  <div class="form-group">
                    <label class="col-form-label" for="inputSuccess">Jenis Simpanan</label>
                        <div class="custom-control custom-radio">
                          <input class="custom-control-input" type="radio" id="customRadio1" name="customRadio" value="<?php echo $j['wajib']; ?>" onClick="jenisW()">
                          <label for="customRadio1" class="custom-control-label">Wajib</label>
                        </div>
                        <div class="custom-control custom-radio">
                          <input class="custom-control-input" type="radio" id="customRadio2" name="customRadio" value="<?php echo $j['sukarela']; ?>" onClick="jenisS()">
                          <label for="customRadio2" class="custom-control-label">Sukarela</label>
                        </div>
                  </div><hr>
                  <div class="form-group">
                    <label class="col-form-label" for="inputSuccess">Jenis</label>
                    <input type="text" class="form-control" name="jenis" id="jenis" placeholder="jenis simpanan ..." readonly>
                  </div>
                  <div class="form-group">
                    <label class="col-form-label" for="inputSuccess">Jumlah</label>
                    <input type="text" class="form-control" name="jumlah" id="jumlah" placeholder="jumlah ...">
                  </div>
                  </div>
                <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <div class="col-md-6">
            <!-- general form elements disabled -->
            <div class="card card-body">
              <div class="col-sm-6">
                      <div class="form-group">
                        <label>Kode User</label>
                        <input type="text" class="form-control" name="kode_user" value="<?php echo $user['kode_user']; ?>" placeholder="kode_user ..." readonly>
                      </div>
                      <div class="form-group">
                        <label>ID Anggota</label>
                        <select class="custom-select" name="id_anggota">
                          <option>--id anggota---</option>
                          <?php 
                          $query = mysqli_query($koneksi, "SELECT * FROM tb_anggota ORDER BY id_anggota ASC");
                          if (mysqli_num_rows($query)>0) {
                            while ($row = mysqli_fetch_array($query)) {
                             echo '<option value="'.$row['id_anggota'].'">'.$row['id_anggota'].'</option>'; 
                            }
                          } ?>
                          
                        </select>
                      </div>
                  </div>
            </div>
            <div class="card">
              <div class="card-footer">
                  <button type="submit" name="save" class="btn btn-app bg-danger">
                  <i class="fas fa-save"></i> Save</button>
                  
                  <a type="submit" href="../dasboard.php" class="btn btn-app bg-warning">
                  <i class="fas"></i>Cencel</a>
                </div>
            </div>
          </div>
        </div>
        </form>
      </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <?php include "../../footer.php"; ?>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!---->
<script type="text/javascript">
  function jenisW() {
    var jeni = 'Wajib';
    var jen1 = document.getElementById('customRadio1').value;
    document.getElementById('jumlah').value = jen1;
    document.getElementById('jenis').value = jeni;
  }
  function jenisS() {
    var jeni = 'Sukarela';
    var jen2 = document.getElementById('customRadio2').value;
    document.getElementById('jumlah').value = jen2;
    document.getElementById('jenis').value = jeni;
  }
</script>
<!--/-->

<!-- jQuery -->
<script src="../../plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../../dist/js/demo.js"></script>
</body>
</html>
