<?php 
include "../../koneksi/koneksi.php";

$id =$_GET['id'];
$query = mysqli_query($koneksi, "DELETE FROM tb_penarikan_sim WHERE id_penarikan='".$id."'");

if ($query) {
		echo "<script>
			alert('Penarikan Tidak DI Acc');
			document.location.href = 'persetujuan_penarikan.php';
		</script>";
}else {
		echo "<script>
			alert('Penarikan Gagal Di Hapus');
			document.location.href = 'persetujuan_penarikan.php';
		</script>";
}
?>