<?php 
include "../../koneksi/koneksi.php";

if (isset($_POST['save'])) {
	$id_penarikan = $_POST['id_penarikan'];
	$tgl_penarikan = $_POST['tgl_penarikan'];
	$jumlah =$_POST['jumlah'];
	$ket = $_POST['keterangan'];
	$id_anggota = $_POST['id_anggota'];
	$kode_user = $_POST['kode_user'];

	$angka=range(0,9);
	shuffle($angka);
	$sembilan=array_rand($angka, 6);
	$angkaString = implode("W", $sembilan);
	$kode=$angkaString;

	$cek = mysqli_query($koneksi, "SELECT id_penarikan FROM tb_persetujuan_pin WHERE id_penarikan ='$id_penarikan'");

	if ($del = mysqli_fetch_assoc($cek)) {
		echo "<script>
			alert('Penarikan sudah pernah');
			document.location.href = 'persetujuan_pinjaman.php';
		</script>";
		return false;
	}else{
		$query = mysqli_query($koneksi, "INSERT INTO tb_persetujuan_pin(id_penarikan, tgl_penarikan, jumlah, keterangan, id_anggota, kode_user) 
		VALUES('$kode','$tgl_penarikan','$jumlah','$ket','$id_anggota','$kode_user')");
	if ($query) {
		echo "<script>
			alert('Pengajuan Penarikan Berhasil Di ACC');
			document.location.href = 'data_penarikan.php';
		</script>";
	}
	}
}
?>