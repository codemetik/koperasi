<?php 
include "../../koneksi/koneksi.php";

if (isset($_POST['tarik'])) {
	$id_tarik = $_POST['id_penarikan'];
	$tgl_tarik = $_POST['tgl_penarikan'];
	$jml = $_POST['jumlah'];
	$ket = $_POST['keterangan'];
	$id_anggota = $_POST['id_anggota'];
	$kd_user = $_POST['kode_user'];

if (!empty($jml)&&!empty($ket)) {
	
	//cari jumlah dalam tb_simpanan untuk perbandingan penarikan simpanan
	$qr = mysqli_query($koneksi, "SELECT SUM(jumlah) AS jumlah FROM tb_tabungan WHERE id_anggota = '$id_anggota'");
	$res = mysqli_fetch_array($qr);
	$juml = $res['jumlah'];
	//ketentuan penarikan dana dalam simpanan
	$keten_penarikan = mysqli_query($koneksi, "SELECT * FROM ketentuan_penarikan");
	$tarik = mysqli_fetch_array($keten_penarikan);

	//format rupiah dari database
	$keten = mysqli_query($koneksi, "SELECT 
CONCAT('Rp. ', FORMAT(min_simpanan,0)) AS min_simpanan, 
CONCAT('Rp. ', FORMAT(max_penarikan,0)) AS max_penarikan, 
CONCAT('Rp. ', FORMAT(min_penarikan,0))  AS min_penarikan 
FROM ketentuan_penarikan");
	$trk = mysqli_fetch_array($keten);
	$min_sim = $trk['min_simpanan']; 
	$min_s = $min_sim;
	$max_ta = $trk['max_penarikan'];
	$max_t = $max_ta;
	$min_ta = $trk['min_penarikan'];
	$min_t = $min_ta;

	//format angka rupiah
	function rupiah($angka)
	{
		$hasil = "Rp. ".number_format($angka,2,',','.');
		return $hasil;
	}
	$rp = rupiah($jml);
	function rupiahku($angka)
	{
		$hasil = "Rp. ".number_format($angka,2,',','.');
		return $hasil;
	}
	$rpe = rupiah($juml);

	//cari kondisi $tarik['min_simpanan'] 
	if ($juml <= $jml ) {
		echo "<script>
			alert('Maaf dana simpanan anda sementara ini hanya : $rpe');
			document.location.href = 'penarikan_simpanan.php';
			</script>";
	}else{
		if ($jml <= $tarik['max_penarikan']) {
			if ($jml <= $tarik['min_penarikan']) {
				echo "<script>
			alert(' Maaf minimal Penarikan Hanya : $min_t');
			document.location.href = 'penarikan_simpanan.php';
			</script>";
			}else{
					$query = mysqli_query($koneksi, "INSERT INTO tb_penarikan_sim(id_penarikan, tgl_penarikan, jumlah, keterangan, id_anggota, kode_user) VALUES('$id_tarik','$tgl_tarik','$jml','$ket','$id_anggota','$kd_user')");
					if($query){
							echo "<script>
						alert('Dana simpanan berhasil ditarik sebesar : $rp ');
						document.location.href = '../Anggota-baru/detail.php?id=$id_anggota';
						</script>";
						}
			}
		}else{
			echo "<script>
			alert('Maaf dana penarikan harus >= $min_t');
			document.location.href = 'penarikan_simpanan.php';
			</script>";
		}
	}
}else{
	echo "<script>
			alert('Maaf anda harus melengkapi isian form');
			document.location.href = 'penarikan_simpanan.php';
		</script>";
}

}
?>