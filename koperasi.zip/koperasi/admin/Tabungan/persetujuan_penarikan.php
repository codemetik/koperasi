<?php 
session_start();

if (!isset($_SESSION['login'])) {
  header("Location:../login.php");
}

include "../../koneksi/koneksi.php";

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <link rel="icon" type="image/png" href="../../img/logo_kp_indonesia.png">
  <title>Koperasi | Cipta Harapan Jaya</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>
<body class="hold-transition sidebar-mini layout-navbar-fixed">
<!-- Site wrapper -->
<div class="wrapper">
  <?php include "navbar.php"; ?>
  <?php 
    $use = $_SESSION['user'];
    $qr = mysqli_query($koneksi, "SELECT * FROM tb_user WHERE nama_user = '$use'");
$user = mysqli_fetch_assoc($qr);

$J_smpn = mysqli_query($koneksi, "SELECT * FROM jenis_simpanan");
$j = mysqli_fetch_array($J_smpn);
  ?>
  <?php include "sidebar_content.php"; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Persetujuan Penarikan</h3>

                <div class="card-tools">
                  <form action="persetujuan_penarikan.php" method="GET">
                  <div class="input-group input-group-sm" style="width: 250px;">
                    <input type="text" name="tb_search" class="form-control float-right" placeholder="Search">

                    <div class="input-group-append">
                      <button type="submit" class="btn btn-default"><i class="fas fa-search"></i></button>
                    <a href="persetujuan_penarikan.php" class="btn btn-primary">Refresh</a>
                  
                    </div>
                  </div>
                  </form>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0" style="height: 600px;">
                <table class="table table-head-fixed">
                  <thead class="text-center">
                    <tr>
                      <th>ID Penarikan</th>
                      <th>Tanggal Penarikan</th>
                      <th>Jumlah</th>
                      <th>Keterangan</th>
                      <th>ID Anggota</th>
                      <th>Kode User</th>
                      <th>Nama Anggota</th>
                      <th>Acc</th>
                      <th>No Acc</th>
                    </tr>
                  </thead>
                  <?php 
                    include "../../koneksi/koneksi.php";
                    if (isset($_GET['tb_search'])) {
                      $cari = $_GET['tb_search'];
                      $query = mysqli_query($koneksi, "SELECT id_penarikan, tgl_penarikan, jumlah, keterangan, X.id_anggota, X.kode_user, nama_lengkap FROM tb_penarikan_sim X INNER JOIN tb_anggota Y ON Y.id_anggota = X.id_anggota WHERE nama_lengkap LIKE '%".$cari."%' OR X.id_anggota LIKE '%".$cari."%'");
                    }else{
                    $query = mysqli_query($koneksi, "SELECT id_penarikan, tgl_penarikan, jumlah, keterangan, X.id_anggota, X.kode_user, nama_lengkap FROM tb_penarikan_sim X INNER JOIN tb_anggota Y ON Y.id_anggota = X.id_anggota");
                  }
                    while ($data = mysqli_fetch_array($query)) {
                  ?>
                  <tbody class="text-center">
                    <tr>
                      <td><?php echo $data['id_penarikan']; ?></td>
                      <td><?php echo $data['tgl_penarikan']; ?></td>
                      <td><?php echo $data['jumlah']; ?></td>
                      <td><?php echo $data['keterangan']; ?></td>
                      <td><?php echo $data['id_anggota']; ?></td>
                      <td><?php echo $data['kode_user']; ?></td>
                      <td><?php echo $data['nama_lengkap']; ?></td>
                      <td>
                        <a href="detail_persetujuan.php?id=<?php echo $data['id_penarikan']; ?>">
                        <i class="fas fa-inbox"></i> Acc
                        </a>
                      </td>
                      <td>
                        <a href="delete_persetujuan.php?id=<?php echo $data['id_penarikan']; ?>">
                        <i class="fas fa-edit"></i> NoAcc
                        </a>
                      </td>
                    <?php } ?>
                    </tr>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
       
      </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <?php include "../../footer.php"; ?>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!---->
<script type="text/javascript">
  
</script>
<!--/-->

<!-- jQuery -->
<script src="../../plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../../dist/js/demo.js"></script>
</body>
</html>