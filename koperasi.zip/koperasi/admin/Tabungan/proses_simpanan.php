<?php 
include "../../koneksi/koneksi.php";
if (isset($_POST['save'])) {
	$id_simpanan = $_POST['id_simpanan'];
	$tgl = $_POST['tgl_simpan'];
	$jns_simpan = $_POST['jenis'];
	$jumlah = $_POST['jumlah'];
	$kd_user = $_POST['kode_user'];
	$id_agt = $_POST['id_anggota'];

if (!empty($jns_simpan)&&!empty($jumlah)) {
	$query = mysqli_query($koneksi, "INSERT INTO tb_simpanan(id_simpanan, tgl_simpan, jenis_simpanan, jumlah, kode_user, id_anggota) VALUES('$id_simpanan','$tgl','$jns_simpan','$jumlah','$kd_user','$id_agt')");

	if ($query) {
		echo "<script>
			alert('Data Simpanan berhasil di simpan');
			document.location.href = 'data_simpanan.php';
		</script>";
	}

}else{
	echo "<script>
			alert('Maaf anda harus melengkapi isian form');
			document.location.href = 'simpanan.php';
		</script>";
}
}
?>