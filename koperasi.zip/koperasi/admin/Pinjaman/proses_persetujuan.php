<?php 
include "../../koneksi/koneksi.php";

if (isset($_POST['save'])) {
	$tgl_join = $_POST['tgl_pinjam'];
	$jumlah =$_POST['jumlah'];
	$bunga = $_POST['bunga'];
	$cicilan = $_POST['lama_cicilan'];
	$angsuran = $_POST['angsuran'];
	$hutang = $_POST['hutang'];
	$kode_user = $_POST['kode_user'];
	$id_anggota = $_POST['id_anggota'];

	$angka=range(0,9);
	shuffle($angka);
	$sembilan=array_rand($angka, 6);
	$angkaString = implode("P", $sembilan);
	$kode=$angkaString;

	$cek = mysqli_query($koneksi, "SELECT id_anggota FROM tb_pinjaman WHERE id_anggota ='$id_anggota'");

	if ($del = mysqli_fetch_assoc($cek)) {
		echo "<script>
			alert('Anggota Sudah Ada');
			document.location.href = 'persetujuan_pinjaman.php';
		</script>";
		return false;
	}else{
		$query = mysqli_query($koneksi, "INSERT INTO tb_pinjaman(id_pinjaman, tgl_pinjam, jumlah, bunga, lama_cicilan, angsuran, hutang, kode_user, id_anggota) 
		VALUES('$kode','$tgl_join','$jumlah','$bunga','$cicilan','$angsuran','$hutang','$kode_user','$id_anggota')");
		$insert = mysqli_query($koneksi, "INSERT INTO slip_pinjaman(id_pin, tgl_pin, jum, bung, lama_cicil, angsur, utang, kode_user, id_anggota) VALUES('$kode','$tgl_join','$jumlah','$bunga','$cicilan','$angsuran','$hutang','$kode_user','$id_anggota')");
	if ($query&&$insert) {
		echo "<script>
			alert('Pengajuan Berhasil Di ACC');
			document.location.href = 'data_pinjaman.php';
		</script>";
	}
	}
}
?>