<?php 
include "../../koneksi/koneksi.php";

$id =$_GET['id'];
$query = mysqli_query($koneksi, "DELETE FROM tb_persetujuan WHERE id_pinjam='".$id."'");

if ($query) {
		echo "<script>
			alert('Pinjaman Tidak DI Acc');
			document.location.href = 'persetujuan_pinjaman.php';
		</script>";
}else {
		echo "<script>
			alert('Pinjaman Gagal Di Hapus');
			document.location.href = 'persetujuan_pinjaman.php';
		</script>";
}
?>