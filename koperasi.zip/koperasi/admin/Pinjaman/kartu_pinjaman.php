<?php 
session_start();

if (!isset($_SESSION['login'])) {
  header("Location:../login.php");
}
include "../../koneksi/koneksi.php";

$query = mysqli_query($koneksi, "SELECT max(id_pinjam) AS maxkode FROM tb_persetujuan");
$data = mysqli_fetch_array($query);
$kdPinjam = $data['maxkode'];
$noUrut = (int)substr($kdPinjam, 3, 4);
$noUrut++;
$char = "PIN";
$kdPinjam = $char . sprintf("%04s", $noUrut); 

$tanggal = date("Y-m-d H:i:s");

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <link rel="icon" type="image/png" href="../../img/logo_kp_indonesia.png">
  <title>Koperasi | Cipta Harapan</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>
<body class="hold-transition sidebar-mini layout-navbar-fixed">
<!-- Site wrapper -->
<div class="wrapper">
  <?php include "navbar.php"; ?>
  <?php 
    $use = $_SESSION['user'];
    $qr = mysqli_query($koneksi, "SELECT * FROM tb_user WHERE nama_user = '$use'");
$user = mysqli_fetch_assoc($qr);
  ?>
  <?php include "sidebar_content.php"; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!--Code Mysqli Disini-->
      <div class="card card-solid">
        <div class="card-body pb-0">
          <!--search-->
          <div class="card-tools mb-3">
            <form action="kartu_pinjaman.php" method="GET">
              <div class="input-group input-group-sm" style="width: 250px;">
                  <input type="text" name="table_search" class="form-control float-right" placeholder="Search">

                  <div class="input-group-append">
                    <button type="submit" class="btn btn-default"><i class="fas fa-search"></i></button>
                    <a href="kartu_pinjaman.php" class="btn btn-primary">Refresh</a>
                  
                  </div>
              </div>
            </form>
          </div><!--/search-->
          <div class="row d-flex align-items-stretch">
            <!--Cart Contact-->
            <?php 
            if (isset($_GET['table_search'])) {
            $cari = $_GET['table_search'];
            $card = mysqli_query($koneksi, "SELECT id_pin , tgl_pin, CONCAT('Rp. ',FORMAT(jum,0)) AS jum , bung, lama_cicil, CONCAT('Rp. ', FORMAT(angsur,0)) AS angsur, CONCAT('Rp. ', FORMAT(utang,0)) AS utang, X.kode_user, X.id_anggota, nama_lengkap FROM slip_pinjaman X INNER JOIN tb_anggota Y ON Y.id_anggota = X.id_anggota WHERE X.id_pin LIKE '%".$cari."%' OR nama_lengkap LIKE '%".$cari."%'");
            }else{
            $card = mysqli_query($koneksi, "SELECT id_pin , tgl_pin, CONCAT('Rp. ',FORMAT(jum,0)) AS jum , bung, lama_cicil, CONCAT('Rp. ', FORMAT(angsur,0)) AS angsur, CONCAT('Rp. ', FORMAT(utang,0)) AS utang, X.kode_user, X.id_anggota, nama_lengkap FROM slip_pinjaman X INNER JOIN tb_anggota Y ON Y.id_anggota = X.id_anggota");
          }
            while ($card_data = mysqli_fetch_array($card)) { ?>
        <div class="col-12 col-sm-6 col-md-4 d-flex align-items-stretch">
          <div class="card bg-primary">
              <div class="card-header text-muted border-bottom-0 bg-dark">
                  Koperasi Cipta Harapan Jaya
                </div>
                <div class="card-body pt-0">
                  <div class="row mt-3">
                    <div class="col-7">
                      <h2 class="lead text-dark"><b><?php echo $card_data['nama_lengkap'] ?></b></h2>
                      <h2 class="lead text-dark"><b><?php echo $card_data['id_pin'] ?></b></h2>
                      <p class="text-dark text-sm"><b>Tgl Pinjam: </b> <?php echo $card_data['tgl_pin']; ?></p>
                      <ul class="ml-4 mb-0 fa-ul text-dark">
                        <li class="small"> Id Anggota: <?php echo $card_data['id_anggota']; ?></li>
                        <li class="small"> Kode User #: <?php echo $card_data['kode_user']; ?></li>
                      </ul>
                      <p class="text-dark text-sm"><b><?php echo $card_data['utang']; ?></b></p>
                    </div>
                    <div class="col-5 text-center">
                      <img src="../../img/koperasi.png" alt="" class="img-circle img-fluid">
                    </div>
                  </div>
                </div>
                <div class="card-footer">
                  <div class="text-right">
                    <a href="print_pinjm.php?id=<?php echo $card_data['id_pin']; ?>" class="btn btn-sm btn-primary" target="_BLANK">
                      <i class="fas fa-print"></i> Print PDF
                    </a>
                  </div>
                </div>
              </div>
            </div><!--/Cart Contact-->
          <?php } ?>
            </div>
          </div>
        </div>
        <!--/code-->
      </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <?php include "../../footer.php"; ?>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->
<!--script-->
  <script type="text/javascript">
    function klik() {
      var jum = parseInt(document.getElementById('jumlah').value);
      var bung = parseInt(document.getElementById('bunga').value);
      var cicil = parseInt(document.getElementById('cicil').value);
      
      var hasil = Math.round((bung/100)*(cicil/12)*jum);
      var has = jum+hasil;
      var cari_angsur = Math.round(has/cicil);
      document.getElementById('angsuran').value = cari_angsur;
      document.getElementById('hutang').value = has;

    }
  </script>
<!--/script-->

<!-- jQuery -->
<script src="../../plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../../dist/js/demo.js"></script>
</body>
</html>