<?php 
include "../../koneksi/koneksi.php";

if (isset($_POST['refresh'])) {
		$n = mysqli_query($koneksi, "DELETE FROM tb_pinjaman WHERE hutang ='0'");
		if ($n) {
			echo "<script>
				alert('Data Berhasil Dihapus');
				document.location.href='data_pinjaman.php';
			</script>";
		}else{
			echo "<script>
				alert('OK Siph');
				document.location.href='data_pinjaman.php';
			</script>";
		}
}
?>