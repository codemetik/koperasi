<?php 
include "../../koneksi/koneksi.php";

$id = $_GET['id'];
$query = mysqli_query($koneksi, "DELETE FROM tb_persetujuan WHERE id_anggota= '".$id."'");
if ($query) {
	echo "<script>
			alert('Terimakasih Atas Pengajuannya');
			document.location.href = 'persetujuan_pinjaman.php';
		</script>";
}

?>