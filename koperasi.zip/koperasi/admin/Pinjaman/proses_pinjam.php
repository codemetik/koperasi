<?php
include "../../koneksi/koneksi.php";

if (isset($_POST['save'])) {

	$id_pjm = $_POST['id_pinjam'];
	$tgl = $_POST['tgl_pinjam'];
	$jum = $_POST['jumlah'];
	$bung = $_POST['bunga'];
	$cicil = $_POST['cicil'];
	$angsur = $_POST['angsuran'];
	$hut = $_POST['hutang'];
	$kd_user = $_POST['kode_user'];
	$id_anggota = $_POST['id_anggota'];
	
				$query = mysqli_query($koneksi, "SELECT id_anggota FROM tb_persetujuan WHERE id_anggota = '$id_anggota'");

			if (mysqli_fetch_assoc($query)) {
				echo "<script>
					alert('Anggota sudah ada!');
					document.location.href = 'pinjam.php';
				</script>";
				return false;
			}else{
				$query = mysqli_query($koneksi, "INSERT INTO tb_persetujuan(id_pinjam, tgl_pinjam, jumlah, bunga, lama_cicilan, angsuran, hutang, kode_user, id_anggota) VALUES('$id_pjm','$tgl','$jum','$bung','$cicil','$angsur','$hut','$kd_user','$id_anggota')");

					if ($query) {
						echo "<script>
							alert('Data Pengajuan Simpanan Akan Segera Di Proses');
							document.location.href = 'persetujuan_pinjaman.php';
						</script>";
						}
			}

}





?>