<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <link rel="icon" type="image/png" href="../../img/logo_kp_indonesia.png">
  <title>Koperasi | Cipta Harapan Jaya</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>
<body class="hold-transition sidebar-mini sidebar-collapse">
<!-- Site wrapper -->
<div class="wrapper">

  <!-- Main Sidebar Container -->


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
      <?php 
      include "../../koneksi/koneksi.php";
      $id = $_GET['id'];
      $query = mysqli_query($koneksi, "SELECT id_pin , tgl_pin, CONCAT('Rp. ',FORMAT(jum,0)) AS jum , bung, lama_cicil, CONCAT('Rp. ', FORMAT(angsur,0)) AS angsur, CONCAT('Rp. ', FORMAT(utang,0)) AS utang, X.kode_user, X.id_anggota, nama_lengkap FROM slip_pinjaman X INNER JOIN tb_anggota Y ON Y.id_anggota = X.id_anggota WHERE X.id_pin = '".$id."'");
      $data = mysqli_fetch_array($query);
      ?>
        <div class="card-header bg-dark">
        <div class="text-center">
          <h3>SLIP PINJAMAN </h3>
          <h3>Cipta Harapan Jaya</h3>
          <hr>
        </div>
        </div>
        <table class="table">
          <tr>
            <th>Nama Lengkap</th>
            <td>: <?php echo $data['nama_lengkap']; ?></td>
          </tr>
          <tr>
            <th>TGL Join</th>
            <td>: <?php echo $data['tgl_pin']; ?></td>
          </tr>
          <tr>
            <th>Jumlah</th>
            <td>: <?php echo $data['jum'];  ?> </td>
          </tr>
          <tr>
            <th>Bunga</th>
            <td>: <?php echo $data['bung']; ?> %</td>
          </tr>
          <tr>
            <th>Lama Cicilan</th>
            <td>: <?php echo $data['lama_cicil']; ?> bulan</td>
          </tr>
          <tr>
            <th>Angsuran/bulan</th>
            <td>: <?php echo $data['angsur']; ?></td>
          </tr>
          <tr>
            <th>Hutang</th>
            <td>: <?php echo $data['utang']; ?></td>
          </tr>
          <tr>
            <th>ID Pinjaman</th>
            <td>: <?php echo $data['id_pin']; ?></td>
          </tr>
          <tr>
            <th>ID Anggota</th>
            <td>: <?php echo $data['id_anggota']; ?></td>
          </tr>
          <tr>
            <th>Kode User</th>
            <td>: <?php echo $data['kode_user']; ?></td>
          </tr>
        </table>
      </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>Version</b> 0.0.0
    </div>
    <strong>Copyright &copy; 2019 <a href="#">Cipta Harapan Jaya</a></strong>
  </footer>

  
</div>
<!-- ./wrapper -->
<script type="text/javascript">
  window.print();
</script>
<!-- jQuery -->
<script src="../../plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../../dist/js/demo.js"></script>
</body>
</html>
