<?php 
include "../../koneksi/koneksi.php";

$id = $_POST['id_anggota'];
$nama_l = htmlspecialchars($_POST['nama_lengkap']);
$almt = $_POST['alamat'];
$tlp = $_POST['tlp'];
$sim_pokok = $_POST['simpanan_pokok'];
$sim_wajib = $_POST['simpanan_wajib'];
$sim_sukarela = $_POST['simpanan_sukarela'];
$saldo = $_POST['saldo'];
$status = $_POST['status'];


$query = mysqli_query($koneksi, "UPDATE tb_anggota SET nama_lengkap='".$nama_l."', alamat='".$almt."', telephone='".$tlp."', simpanan_pokok='".$sim_pokok."', simpanan_wajib='".$sim_wajib."',simpanan_sukarela='".$sim_sukarela."', saldo='".$saldo."', status='".$status."' WHERE id_anggota='".$id."' ");

if ($query) {
	echo "<script>
		alert('Data Anggota Berhasil Di Update');
		document.location.href = 'data_anggota.php';
	</script>";
}else{
	echo "Maaf data Gagal Diedit!";
}

?>