<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <link rel="icon" type="image/png" href="../../img/logo_kp_indonesia.png">
  <title>Koperasi | Cipta Harapan Jaya</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>
<body class="hold-transition sidebar-mini sidebar-collapse">
<!-- Site wrapper -->
<div class="wrapper">

  <!-- Main Sidebar Container -->


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <?php 
        include "../../koneksi/koneksi.php";
        $id = $_GET['id'];
        $query = mysqli_query($koneksi, "SELECT * FROM tb_anggota WHERE id_anggota ='".$id."'");
        $data = mysqli_fetch_array($query);
        ?>
      <div class="card card-solid">
        <div class="card-body pb-0">
          <div class="col-12 col-sm-6 col-md-4 d-flex align-items-stretch">
          <div class="card bg-warning">
                <div class="card-header text-muted border-bottom-0 bg-dark">
                  Koperasi Cipta Harapan Jaya
                </div>
                <div class="card-body pt-0">
                  <div class="row mt-3">
                    <div class="col-7">
                      <h2 class="lead"><b><?php echo $data['nama_lengkap'] ?></b></h2>
                      <p class="text-muted text-sm"><b>ID Anggota: </b> <?php echo $data['id_anggota']; ?></p>
                      <ul class="ml-4 mb-0 fa-ul text-muted">
                        <li class="small"><span class="fa-li"><i class="fas fa-lg fa-building"></i></span> Address: <?php echo $data['alamat']; ?></li>
                        <li class="small"><span class="fa-li"><i class="fas fa-lg fa-phone"></i></span> Phone #: <?php echo $data['telephone']; ?></li>
                      </ul>
                      <p class="text-muted text-sm"><b><?php echo $data['tgl_join']; ?></b></p>
                    </div>
                    <div class="col-5 text-center">
                      <img src="../../img/koperasi.png" alt="" class="img-circle img-fluid">
                    </div>
                  </div>
                </div>
              </div>
            </div><!--/Cart Contact-->
          </div>
        </div>
      </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>Version</b> 0.0.0
    </div>
    <strong>Copyright &copy; 2019 <a href="#">Cipta Harapan Jaya</a></strong>
  </footer>

  
</div>
<!-- ./wrapper -->
<script type="text/javascript">
  window.print();
</script>
<!-- jQuery -->
<script src="../../plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../../dist/js/demo.js"></script>
</body>
</html>
