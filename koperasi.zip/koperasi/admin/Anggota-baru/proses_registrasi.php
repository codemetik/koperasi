<?php 
include "../../koneksi/koneksi.php";


if (isset($_POST['save'])) {
	$id_agt = $_POST['id_anggota'];
	$tgl_join = $_POST['tgl_join'];
	$nm_lnkp = htmlspecialchars($_POST['nama_lengkap']);
	$almt = htmlspecialchars($_POST['alamat']);
	$tlp = htmlspecialchars($_POST['tlp']);
	$status = htmlspecialchars($_POST['status']);
	$kd_user = $_POST['kode_user'];
	$pokok = $_POST['simpanan_pokok'];
	$wajib = $_POST['simpanan_wajib'];
	$sukarela = $_POST['simpanan_sukarela'];
	$saldo = $_POST['saldo'];

	if (!empty($nm_lnkp)&&!empty($almt)&&!empty($tlp)&&!empty($status)&&!empty($saldo)) {
	$query = mysqli_query($koneksi, "INSERT INTO tb_anggota(id_anggota, kode_user, tgl_join, nama_lengkap, alamat, telephone, simpanan_pokok, simpanan_wajib, simpanan_sukarela, saldo, status) 
		VALUES('$id_agt','$kd_user','$tgl_join','$nm_lnkp','$almt','$tlp','$pokok','$wajib','$sukarela','$saldo','$status')");
		if ($query) {
			echo "<script>
				alert('Data Anggota berhasil di simpan');
				document.location.href = 'data_anggota.php';
			</script>";
		}
	}else{
		echo "<script>
			alert('Maaf anda harus melengkapi isian form');
			document.location.href = 'registrasi.php';
		</script>";
	}


}

?>