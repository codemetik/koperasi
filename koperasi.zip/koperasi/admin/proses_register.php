<?php 
session_start();
include "../koneksi/koneksi.php";

if (isset($_POST['register'])) {

	$kde = $_POST['kode'];
	$fullnm = htmlspecialchars($_POST['fullname']);
	$username = strtolower(stripcslashes($_POST['username'])); //inputan dengan huruf kecil
	$pwd = mysqli_real_escape_string($koneksi,$_POST['password']); //rahasia password paling aman saat ini

	$pw = password_hash($pwd, PASSWORD_DEFAULT);

	$query = mysqli_query($koneksi, "SELECT username FROM tb_user WHERE username = '$username'");

	if (mysqli_fetch_assoc($query)) {
		echo "<script>
			alert('Username sudah ada!');
		</script>";
		return false;
	}else{
		$query = mysqli_query($koneksi, "INSERT INTO tb_user(kode_user, username, password , nama_user) 
		VALUES('$kde', '$username', '$pw', '$fullnm')");
		if ($query) {
			echo "<script>
			alert('Register admin berhasil');
			document.location.href = 'login.php';
		</script>";
		}
		
	}


}
?>