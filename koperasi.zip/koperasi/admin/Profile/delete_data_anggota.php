<?php 
include "../../koneksi/koneksi.php";

$id = $_GET['id'];
$delete = mysqli_query($koneksi, "DELETE FROM tb_anggota WHERE id_anggota = '".$id."'");

if ($delete) {
		echo "<script>
			alert('Anggota $id Berhasil di hapus');
			document.location.href = 'profile.php';
		</script>";
}else {
		echo "<script>
			alert('Anggota $id Gagal di hapus');
			document.location.href = 'profile.php';
		</script>";
}

?>