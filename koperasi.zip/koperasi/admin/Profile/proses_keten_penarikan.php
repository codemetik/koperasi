<?php 
include "../../koneksi/koneksi.php";

if (isset($_POST['jenis'])) {
	$min_s = $_POST['min_s'];
	$max_t = $_POST['max_t'];
	$min_t = $_POST['min_t'];

	$query = mysqli_query($koneksi, "UPDATE ketentuan_penarikan SET min_simpanan='".$min_s."', max_penarikan='".$max_t."', min_penarikan='".$min_t."'");
	if ($query) {
		echo "<script>
			alert('Ketentuan Penarikan Simpanan Telah Berubah');
			document.location.href = 'profile.php';
		</script>";
	}
}

?>