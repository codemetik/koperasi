<?php 
include "../../koneksi/koneksi.php";

if (isset($_POST['jenis'])) {
	$pokok = $_POST['pokok'];
	$wajib = $_POST['wajib'];
	$sukarela = $_POST['sukarela'];

	$query = mysqli_query($koneksi, "UPDATE jenis_simpanan SET pokok='".$pokok."', wajib='".$wajib."', sukarela='".$sukarela."'");
	if ($query) {
		echo "<script>
			alert('Ketentuan Jenis Simpanan Telah Berubah');
			document.location.href = 'profile.php';
		</script>";
	}
}

?>