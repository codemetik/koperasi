<?php 
session_start();
include "../koneksi/koneksi.php";

if (isset($_POST['submit'])) {
	$username = $_POST['username'];
	$password = $_POST['password'];

	$result = mysqli_query($koneksi, "SELECT * FROM tb_user WHERE username = '$username'");
	$query = mysqli_query($koneksi, "SELECT * FROM tb_user WHERE kode_user");
	$r = mysqli_fetch_assoc($query);
	//cek username 
	if (mysqli_num_rows($result)===1) {

		//cek password
		$row = mysqli_fetch_assoc($result);
		if (password_verify($password, $row['password'])) {
			$_SESSION['login'] = true;
			$_SESSION['user'] = $row['nama_user'];
			$_SESSION['kd'] = $row['password'];
			echo "<script>
				alert('Selamat Username dan Password Benar');
				document.location.href='login.php';
			</script>";
			exit;
		}
	}
	$error = true;

	if ($error) {
		echo "<script>
				alert('Maaf Username tidak ada');
				document.location.href='login.php';
			</script>";
	}
}

?>